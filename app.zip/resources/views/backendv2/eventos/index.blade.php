@extends('layouts.backendv2.app')

@section('contenido')
    @livewire('eventos-livewire')
@endsection