@extends('layouts.backendv2.app')

@section('contenido')
    @livewire('misentradas.todos-livewire')
@endsection

